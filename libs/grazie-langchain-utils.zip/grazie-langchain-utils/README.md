# Grazie 🤝 LangChain

This library provides the wrappers for [Grazie Python client](https://jetbrains.team/p/grazi/packages/pypi/jetbrains-ai-platform-public/grazie-api-gateway-client?v=0.1.0) 
to be used with [LangChain](https://github.com/langchain-ai/langchain) – a framework for LLM applications.

## Table of contents

1. [⚙️ Installation](#installation)
2. [💬 Chat Model](#chat-model)
3. [🤖 Agent Utilities](#agent-utilities)
   1. [🦜️🔗 LangChain](#-langchain-agentexecutor)
   2. [🦜🕸 LangGraph](#-langgraph)
4. [💵 Tracking usage](#tracking-usage)
5. [🚦 Rate Limiting](#rate-limiting)
6. [💻 Code Owners](#code-owners)


# ⚙️ Installation

The library is published as a [package](https://jetbrains.team/p/ml-4-se-lab/packages/pypi/ai-agents/grazie-langchain-utils?v=0.0.4) to `ai-agents` Space repository.

To add the package as a dependency via [Poetry](https://python-poetry.org/), follow these steps:

1. Manually add the package repository as a source to `pyproject.toml`:

    ```shell
    [[tool.poetry.source]]
    name = "space-ai-agents"
    url = "https://packages.jetbrains.team/pypi/p/ml-4-se-lab/ai-agents/simple"
    priority="supplemental"
    ```

    or run:
   
   ```shell
   poetry source add --priority=supplemental space-ai-agents https://packages.jetbrains.team/pypi/p/ml-4-se-lab/ai-agents/simple
   ```

   **Note:** feel free to change the [priority](https://python-poetry.org/docs/repositories/#project-configuration) to what works best for your case.

2. Configure the credentials to access the package repository:

    ```shell
    poetry config http-basic.space-ai-agents Name.Surname token
    ```
   
    You can get the token by clicking `Connect` (upper right corner) -> `Generate read token` [here](https://jetbrains.team/p/ml-4-se-lab/packages/pypi/ai-agents/grazie-langchain-utils?v=0.0.4).

3. Add the dependency:
    ```shell
    poetry add grazie-langchain-utils --source space-ai-agents
    ```

## 💬 Chat Model

A key part of `grazie-langchain-utils` package is [`ChatGrazie`](grazie_langchain_utils/language_models/grazie.py): implementation of [`BaseChatModel`](https://api.python.langchain.com/en/latest/language_models/langchain_core.language_models.chat_models.BaseChatModel.html#langchain_core.language_models.chat_models.BaseChatModel) LangChain interface 
for Grazie Python package. 

An example of how to use it to send a request to GPT-3.5 Turbo:

```python
import os
from grazie.api.client.endpoints import GrazieApiGatewayUrls
from grazie.api.client.gateway import AuthType
from grazie_langchain_utils.language_models.grazie import ChatGrazie


grazie_llm = ChatGrazie(grazie_jwt_token=os.getenv("GRAZIE_JWT_TOKEN"),
                        client_auth_type=AuthType.USER,
                        client_url=GrazieApiGatewayUrls.STAGING,
                        profile="openai-chat-gpt")

grazie_llm.invoke("how can langsmith help with testing?")
```

## 🤖 Agent utilities

### 🦜️🔗 LangChain (AgentExecutor)

> **Note:** AgentExecutor is [deemed as legacy by LangChain](https://python.langchain.com/v0.2/docs/concepts/#agents), 
> using LangGraph is preferred.

`grazie-langchain-utils` provides a few more utilities to help with the implementation of LangChain agents, 
such as [output parser](grazie_langchain_utils/output_parsers/grazie_functions.py) and [`create_tool_calling_agent` function](grazie_langchain_utils/agents/tool_calling_agent/base.py).

An example of how to define & run a simple Grazie-based agent:

```python
from langchain.agents import AgentExecutor
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import tool
from grazie_langchain_utils.agents import create_tool_calling_agent


@tool
def search(query: str) -> str:
    """Searches the web for a given query."""
    return "Nothing found!"


prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a helpful assistant. Make sure to use the search tool for information.",
        ),
        ("placeholder", "{chat_history}"),
        ("human", "{input}"),
        ("placeholder", "{agent_scratchpad}"),
    ]
)

agent = create_tool_calling_agent(llm=grazie_llm, tools=[search], prompt=prompt)
agent_executor = AgentExecutor(agent=agent, tools=[search], verbose=True)
agent_executor.invoke({"input": "what is langchain?"})
```

### 🦜🕸️ LangGraph

[LangGraph](https://langchain-ai.github.io/langgraph/) is a framework for developing AI agents from LangChain. 
It is currently the recommended option, and it contains many cool features.

You can freely use `ChatGrazie` in LangGraph agents! For instance, below is an example of using [a prebuilt `create_react_agent` method](https://langchain-ai.github.io/langgraph/how-tos/create-react-agent/) with our model,
which is a rough equivalent of AgentExecutor example above:

```python
from langchain_core.tools import tool
from langgraph.prebuilt import create_react_agent

@tool
def search(query: str) -> str:
    """Searches the web for a given query."""
    return "Nothing found!"


graph = create_react_agent(grazie_llm, tools=[search], state_modifier="You are a helpful assistant. Make sure to use the search tool for information.")
graph.invoke({"messages": [("user", "what is langchain?")]})
```

## 💵 Tracking usage

`grazie_langchain_utils` provides a LangChain callback which tracks spent tokens and credits.

As of now, Grazie Python API doesn't return the number of spent tokens, so we approximate it by tokenizing prompts and
returned messages.

The callback can be passed to a model class explicitly:

```python
import os
from grazie.api.client.endpoints import GrazieApiGatewayUrls
from grazie.api.client.gateway import AuthType

from grazie_langchain_utils.callbacks import GrazieInfoCallbackHandler
from grazie_langchain_utils.language_models.grazie import ChatGrazie


grazie_llm = ChatGrazie(grazie_jwt_token=os.getenv("GRAZIE_JWT_TOKEN"),
                        client_auth_type=AuthType.USER,
                        client_url=GrazieApiGatewayUrls.STAGING,
                        profile="openai-chat-gpt",)

cb = GrazieInfoCallbackHandler(grazie_llm.profile)
grazie_llm.invoke("how can langsmith help with testing?", config={"callbacks": [cb]})
print(cb)
```

```output
Tokens Used: 355
	Prompt Tokens: 15
	Completion Tokens: 340
Successful Requests: 1
Total Cost (credits): 68.85
```

Or used as a context manager:

```python
import os
from grazie.api.client.endpoints import GrazieApiGatewayUrls
from grazie.api.client.gateway import AuthType

from grazie_langchain_utils.callbacks import get_token_counter_callback
from grazie_langchain_utils.language_models.grazie import ChatGrazie


grazie_llm = ChatGrazie(grazie_jwt_token=os.getenv("GRAZIE_JWT_TOKEN"),
                        client_auth_type=AuthType.USER,
                        client_url=GrazieApiGatewayUrls.STAGING,
                        profile="openai-chat-gpt",)

with get_token_counter_callback(grazie_llm.profile) as cb:
    grazie_llm.invoke("how can langsmith help with testing?")
    print(cb)
```

```output
Tokens Used: 376
	Prompt Tokens: 15
	Completion Tokens: 361
Successful Requests: 1
Total Cost (credits): 73.05
```

## 🚦 Rate Limiting

Since the version `0.2.24`, LangChain provides [a built-in rate limiter](https://python.langchain.com/docs/how_to/chat_model_rate_limiting/). 
However, it is tailored towards restricting the number of requests per second, while most Grazie rate limits are specified in requests per hour, 
so `grazie_langchain_utils` provides alternative implementation which allows adhering to RPH more precisely.

The usage is the same as LangChain's [`InMemoryRateLimiter`](https://python.langchain.com/api_reference/core/rate_limiters/langchain_core.rate_limiters.InMemoryRateLimiter.html):

```python
import os
from grazie.api.client.endpoints import GrazieApiGatewayUrls
from grazie.api.client.gateway import AuthType

from grazie_langchain_utils.utils import InMemorySlidingWindowRateLimiter
from grazie_langchain_utils.language_models.grazie import ChatGrazie

rate_limiter = InMemorySlidingWindowRateLimiter(max_requests=5000,  # Maximum number of requests allowed for a *period of time*.
                                                window_seconds=3600, #  Duration of the *period of time* in seconds.
                                                check_every_n_seconds=0.1, #  How often to check whether the request is allowed.
                                                )

grazie_llm = ChatGrazie(grazie_jwt_token=os.getenv("GRAZIE_JWT_TOKEN"),
                        client_auth_type=AuthType.USER,
                        client_url=GrazieApiGatewayUrls.STAGING,
                        profile="openai-chat-gpt",
                        rate_limiter=rate_limiter,)

# proceed as usual
grazie_llm.invoke("how can langsmith help with testing?")
```

Note that the current implementation stores up to `max_requests` timestamps in memory, leading to small memory overhead.

# 💻 Code owners

Yury Khudyakov - yury.khudyakov@jetbrains.com

Alexandra Eliseeva - alexandra.eliseeva@jetbrains.com
