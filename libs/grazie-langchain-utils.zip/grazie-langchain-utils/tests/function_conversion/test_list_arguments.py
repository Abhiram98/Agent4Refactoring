import os
from typing import List, Sequence

import pytest
from grazie.api.client.endpoints import GrazieApiGatewayUrls
from grazie.api.client.gateway import AuthType
from langchain_core.tools import tool

from grazie_langchain_utils.language_models.functions_utils import convert_to_json_schema
from grazie_langchain_utils.language_models.grazie import ChatGrazie


@pytest.fixture()
def gt_schema():
    return {
        "name": "search",
        "description": "Searches the web for given queries.",
        "parameters": {
            "type": "object",
            "properties": {"queries": {"type": "array", "items": {"type": "string"}}},
            "required": ["queries"],
        },
    }


@pytest.mark.parametrize("param_type", [list, List, Sequence])
def test_list_argument_conversion(gt_schema, param_type):
    @tool
    def search(queries: param_type[str]) -> str:
        """Searches the web for given queries."""
        return "Nothing found!"

    conversion_result = convert_to_json_schema(search)
    assert conversion_result == gt_schema

    def search(queries: param_type[str]) -> str:
        """Searches the web for given queries."""
        return "Nothing found!"

    conversion_result = convert_to_json_schema(search)
    assert conversion_result == gt_schema


@pytest.mark.slow
@pytest.mark.parametrize("param_type", [list, List, Sequence])
def test_list_argument_full(param_type):
    """NOTE: requires GRAZIE_JWT_TOKEN env variable set
    (& configured accordingly; current code is for user token and staging)"""

    # LangChain tool
    @tool
    def search(queries: param_type[str]) -> str:
        """Searches the web for given queries."""
        return "Nothing found!"

    chat = ChatGrazie(
        grazie_jwt_token=os.getenv("GRAZIE_JWT_TOKEN"),
        client_auth_type=AuthType.USER,
        client_url=GrazieApiGatewayUrls.STAGING,
        profile="openai-chat-gpt",
    )
    chat = chat.bind_tools([search])
    result = chat.invoke("what is langgraph?")
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["name"] == "search"
    assert isinstance(result.tool_calls[0]["args"]["queries"], list)
    assert any("langgraph" in query.lower() for query in result.tool_calls[0]["args"]["queries"])

    # Python function
    def search(queries: param_type[str]) -> str:
        """Searches the web for given queries."""
        return "Nothing found!"

    chat = ChatGrazie(
        grazie_jwt_token=os.getenv("GRAZIE_JWT_TOKEN"),
        client_auth_type=AuthType.USER,
        client_url=GrazieApiGatewayUrls.STAGING,
        profile="openai-chat-gpt",
    )
    chat = chat.bind_tools([search])
    result = chat.invoke("what is langgraph?")
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["name"] == "search"
    assert isinstance(result.tool_calls[0]["args"]["queries"], list)
    assert any("langgraph" in query.lower() for query in result.tool_calls[0]["args"]["queries"])
