import os
from typing import Callable

import pytest
from grazie.api.client.endpoints import GrazieApiGatewayUrls
from grazie.api.client.gateway import AuthType
from langchain_core.tools import BaseTool, tool

from grazie_langchain_utils.language_models.functions_utils import convert_to_json_schema
from grazie_langchain_utils.language_models.grazie import ChatGrazie


@pytest.fixture()
def gt_schema():
    return {
        "name": "search",
        "description": "Searches the given website for a given query.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                },
                "website": {
                    "default": "https://google.com",
                    "type": "string",
                },
            },
            "required": ["query"],
        },
    }


@pytest.fixture()
def search_tool() -> BaseTool:
    @tool
    def search(query: str, website: str = "https://google.com") -> str:
        """Searches the given website for a given query."""
        return "Nothing found!"

    return search


@pytest.fixture()
def search_func() -> Callable:
    def search(query: str, website: str = "https://google.com") -> str:
        """Searches the given website for a given query."""
        return "Nothing found!"

    return search


def test_tool_conversion(gt_schema, search_tool):
    conversion_result = convert_to_json_schema(search_tool)
    assert conversion_result == gt_schema


def test_func_conversion(gt_schema, search_func):
    conversion_result = convert_to_json_schema(search_func)
    assert conversion_result == gt_schema


@pytest.mark.slow
def test_tool_full(search_tool):
    """NOTE: requires GRAZIE_JWT_TOKEN env variable set
    (& configured accordingly; current code is for user token and staging)"""
    chat = ChatGrazie(
        grazie_jwt_token=os.getenv("GRAZIE_JWT_TOKEN"),
        client_auth_type=AuthType.USER,
        client_url=GrazieApiGatewayUrls.STAGING,
        profile="openai-chat-gpt",
    )
    chat = chat.bind_tools([search_tool])
    result = chat.invoke("what is langgraph?")
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["name"] == "search"
    assert "query" in result.tool_calls[0]["args"] and isinstance(result.tool_calls[0]["args"]["query"], str)
    assert "website" not in result.tool_calls[0]["args"]

    result = chat.invoke("what is langgraph? I wonder if github.com could've helped")
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["name"] == "search"
    assert "query" in result.tool_calls[0]["args"] and isinstance(result.tool_calls[0]["args"]["query"], str)
    assert "website" in result.tool_calls[0]["args"] and isinstance(result.tool_calls[0]["args"]["website"], str)


@pytest.mark.slow
def test_py_func_full(search_func):
    """NOTE: requires GRAZIE_JWT_TOKEN env variable set
    (& configured accordingly; current code is for user token and staging)"""
    chat = ChatGrazie(
        grazie_jwt_token=os.getenv("GRAZIE_JWT_TOKEN"),
        client_auth_type=AuthType.USER,
        client_url=GrazieApiGatewayUrls.STAGING,
        profile="openai-chat-gpt",
    )
    chat = chat.bind_tools([search_func])
    result = chat.invoke("what is langgraph?")
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["name"] == "search"
    assert "query" in result.tool_calls[0]["args"] and isinstance(result.tool_calls[0]["args"]["query"], str)
    assert "website" not in result.tool_calls[0]["args"]

    result = chat.invoke("what is langgraph? I wonder if github.com could've helped")
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["name"] == "search"
    assert "query" in result.tool_calls[0]["args"] and isinstance(result.tool_calls[0]["args"]["query"], str)
    assert "website" in result.tool_calls[0]["args"] and isinstance(result.tool_calls[0]["args"]["website"], str)
