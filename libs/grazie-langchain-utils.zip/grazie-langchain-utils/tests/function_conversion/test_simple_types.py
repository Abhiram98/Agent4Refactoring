import os

import pytest
from grazie.api.client.endpoints import GrazieApiGatewayUrls
from grazie.api.client.gateway import AuthType
from langchain_core.tools import tool
from langchain_core.utils.function_calling import PYTHON_TO_JSON_TYPES

from grazie_langchain_utils.language_models.functions_utils import convert_to_json_schema
from grazie_langchain_utils.language_models.grazie import ChatGrazie


@pytest.mark.parametrize("param_type", [bool, int, float, str])
def test_tool_conversion(param_type):
    @tool
    def my_tool(my_param: param_type):
        """Very useful tool."""
        return None

    gt_schema = {
        "name": "my_tool",
        "description": "Very useful tool.",
        "parameters": {
            "type": "object",
            "properties": {
                "my_param": {
                    "type": PYTHON_TO_JSON_TYPES[param_type.__name__],
                }
            },
        },
        "required": ["arg1"],
    }

    converted_schema = convert_to_json_schema(my_tool)
    # TODO: why is it different in this case?
    assert converted_schema == gt_schema


@pytest.mark.parametrize("param_type", [bool, int, float, str])
def test_func_conversion(param_type):
    def my_tool(arg1: param_type):
        """Very useful tool."""
        return None

    gt_schema = {
        "name": "my_tool",
        "description": "Very useful tool.",
        "parameters": {
            "type": "object",
            "properties": {
                "arg1": {
                    "type": PYTHON_TO_JSON_TYPES[param_type.__name__],
                }
            },
        },
        "required": ["arg1"],
    }

    converted_schema = convert_to_json_schema(my_tool)
    # TODO: why is it different in this case?
    assert converted_schema == gt_schema


@pytest.mark.slow
@pytest.mark.parametrize("param_type", [bool, int, float, str])
def test_simple_types_full(param_type):
    """NOTE: requires GRAZIE_JWT_TOKEN env variable set
    (& configured accordingly; current code is for user token and staging)"""
    PARAM_TYPE_TO_VALUE = {bool: False, int: 1, float: 1.0, str: "hello"}

    # LangChain tool
    @tool
    def my_tool(arg1: param_type):
        """Very useful tool."""
        return None

    chat = ChatGrazie(
        grazie_jwt_token=os.getenv("GRAZIE_JWT_TOKEN"),
        client_auth_type=AuthType.USER,
        client_url=GrazieApiGatewayUrls.STAGING,
        profile="openai-chat-gpt",
    )
    chat = chat.bind_tools([my_tool])
    result = chat.invoke(
        f"hey, please use my_tool provided to you. the arg1 argument should be set to {PARAM_TYPE_TO_VALUE[param_type]}. do not ask questions, just return a tool call"
    )
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["name"] == "my_tool"
    assert isinstance(result.tool_calls[0]["args"]["arg1"], param_type)

    # Python function
    def my_tool(arg1: param_type):
        """Very useful tool."""
        return None

    chat = ChatGrazie(
        grazie_jwt_token=os.getenv("GRAZIE_JWT_TOKEN"),
        client_auth_type=AuthType.USER,
        client_url=GrazieApiGatewayUrls.STAGING,
        profile="openai-chat-gpt",
    )
    chat = chat.bind_tools([my_tool])
    result = chat.invoke(
        f"hey, please use my_tool provided to you. the arg1 argument should be set to {PARAM_TYPE_TO_VALUE[param_type]}. do not ask questions, just return a tool call"
    )
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["name"] == "my_tool"
    assert isinstance(result.tool_calls[0]["args"]["arg1"], param_type)
