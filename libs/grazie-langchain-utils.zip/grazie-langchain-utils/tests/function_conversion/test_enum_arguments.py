import os
from enum import Enum
from typing import Callable

import pytest
from grazie.api.client.endpoints import GrazieApiGatewayUrls
from grazie.api.client.gateway import AuthType
from langchain_core.tools import BaseTool, tool

from grazie_langchain_utils.language_models.functions_utils import convert_to_json_schema
from grazie_langchain_utils.language_models.grazie import ChatGrazie


class Priority(Enum):
    """Priority for the current search request."""

    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@pytest.fixture()
def gt_schema():
    return {
        "name": "search",
        "description": "Searches the web for given query.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                },
                "priority": {
                    "description": "Priority for the current search request.",
                    "enum": ["high", "medium", "low"],
                },
            },
            "required": ["query", "priority"],
        },
    }


@pytest.fixture(scope="session")
def search_tool() -> BaseTool:
    @tool
    def search(query: str, priority: Priority) -> str:
        """Searches the web for given query."""
        return "Nothing found!"

    return search


@pytest.fixture(scope="session")
def search_func() -> Callable:
    def search(query: str, priority: Priority) -> str:
        """Searches the web for given query."""
        return "Nothing found!"

    return search


def test_tool_conversion(gt_schema, search_tool):
    conversion_result = convert_to_json_schema(search_tool)
    assert conversion_result == gt_schema


def test_func_conversion(gt_schema, search_func):
    conversion_result = convert_to_json_schema(search_func)
    assert conversion_result == gt_schema


@pytest.mark.slow
def test_tool_full(search_tool):
    """NOTE: requires GRAZIE_JWT_TOKEN env variable set
    (& configured accordingly; current code is for user token and staging)"""
    chat = ChatGrazie(
        grazie_jwt_token=os.getenv("GRAZIE_JWT_TOKEN"),
        client_auth_type=AuthType.USER,
        client_url=GrazieApiGatewayUrls.STAGING,
        profile="openai-chat-gpt",
    )
    chat = chat.bind_tools([search_tool])
    result = chat.invoke("what is langgraph? really not that important...")
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["name"] == "search"
    assert "query" in result.tool_calls[0]["args"] and isinstance(result.tool_calls[0]["args"]["query"], str)
    assert "priority" in result.tool_calls[0]["args"] and result.tool_calls[0]["args"]["priority"] == Priority.LOW.value

    result = chat.invoke("what is langgraph? very important urgent please help ASAP")
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["name"] == "search"
    assert "query" in result.tool_calls[0]["args"] and isinstance(result.tool_calls[0]["args"]["query"], str)
    assert (
        "priority" in result.tool_calls[0]["args"] and result.tool_calls[0]["args"]["priority"] == Priority.HIGH.value
    )


@pytest.mark.slow
def test_py_func_full(search_func):
    """NOTE: requires GRAZIE_JWT_TOKEN env variable set
    (& configured accordingly; current code is for user token and staging)"""
    chat = ChatGrazie(
        grazie_jwt_token=os.getenv("GRAZIE_JWT_TOKEN"),
        client_auth_type=AuthType.USER,
        client_url=GrazieApiGatewayUrls.STAGING,
        profile="openai-chat-gpt",
    )
    chat = chat.bind_tools([search_func])
    result = chat.invoke("what is langgraph? really not that important...")
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["name"] == "search"
    assert "query" in result.tool_calls[0]["args"] and isinstance(result.tool_calls[0]["args"]["query"], str)
    assert "priority" in result.tool_calls[0]["args"] and result.tool_calls[0]["args"]["priority"] == Priority.LOW.value

    result = chat.invoke("what is langgraph? very important urgent please help ASAP")
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0]["name"] == "search"
    assert "query" in result.tool_calls[0]["args"] and isinstance(result.tool_calls[0]["args"]["query"], str)
    assert (
        "priority" in result.tool_calls[0]["args"] and result.tool_calls[0]["args"]["priority"] == Priority.HIGH.value
    )
