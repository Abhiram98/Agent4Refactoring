import pytest
from freezegun import freeze_time

from grazie_langchain_utils.utils.rate_limiter import InMemorySlidingWindowRateLimiter


# mirroring LangChain tests for InMemoryRateLimiter
@pytest.fixture
def rate_limiter() -> InMemorySlidingWindowRateLimiter:
    return InMemorySlidingWindowRateLimiter(max_requests=5000, window_seconds=3600, check_every_n_seconds=1)


def test_sync_wait(rate_limiter) -> None:
    with freeze_time("2023-01-01 00:00:00") as frozen_time:
        for i in range(5000):
            is_allowed = rate_limiter.acquire(blocking=False)
            assert is_allowed
            assert len(rate_limiter.request_timestamps) == i + 1
        assert not rate_limiter.acquire(blocking=False)
        frozen_time.tick(3601)
        assert rate_limiter.acquire(blocking=False)


async def test_async_wait(rate_limiter) -> None:
    with freeze_time("2023-01-01 00:00:00") as frozen_time:
        for i in range(5000):
            is_allowed = await rate_limiter.aacquire(blocking=False)
            assert is_allowed
            assert len(rate_limiter.request_timestamps) == i + 1
        assert not await rate_limiter.aacquire(blocking=False)
        frozen_time.tick(3601)
        assert await rate_limiter.aacquire(blocking=False)
