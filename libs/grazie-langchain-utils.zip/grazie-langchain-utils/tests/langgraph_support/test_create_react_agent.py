from decimal import Decimal
from unittest.mock import MagicMock

import pytest
from grazie.api.client.chat.prompt import ChatPrompt
from grazie.api.client.chat.response import ChatResponse, Credit
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.errors import GraphRecursionError
from langgraph.prebuilt import create_react_agent
from openai.types import CompletionUsage
from openai.types.chat import ChatCompletion, ChatCompletionMessage, ChatCompletionMessageToolCall
from openai.types.chat.chat_completion import Choice
from openai.types.chat.chat_completion_message_tool_call_param import Function

from grazie_langchain_utils.language_models.grazie import ChatGrazie


@tool
def blackbox(a: int, b: int) -> int:
    """Performs some blackbox operation on two numbers."""
    if a == 5 and b == 7 or a == 7 and b == 5:
        return 12
    else:
        return -1


@pytest.fixture(scope="session")
def grazie_llm():
    chat = ChatGrazie(client=MagicMock(), profile="openai-chat-gpt")
    chat.client.chat.return_value = ChatResponse(
        prompt=ChatPrompt(),
        content='{\n  "a": "5", "b": "7"\n}',
        function_call="blackbox",
        spent=Credit(amount=Decimal(2)),
    )
    return chat


@pytest.fixture(scope="session")
def openai_llm():
    chat = ChatOpenAI(client=MagicMock(), openai_api_key="api key")
    chat.client.create.return_value = ChatCompletion(
        id="blahblah",
        choices=[
            Choice(
                finish_reason="tool_calls",
                index=0,
                logprobs=None,
                message=ChatCompletionMessage(
                    content=None,
                    role="assistant",
                    function_call=None,
                    tool_calls=[
                        ChatCompletionMessageToolCall(
                            id="call_blackbox",
                            function=Function(arguments='{\n  "a": "5", "b": "7"\n}', name="blackbox"),
                            type="function",
                        )
                    ],
                    refusal=None,
                ),
            )
        ],
        created=1723639114,
        model="gpt-3.5-turbo-0613",
        object="chat.completion",
        service_tier=None,
        system_fingerprint=None,
        usage=CompletionUsage(completion_tokens=1, prompt_tokens=1, total_tokens=1),
    )
    return chat


def test_new_react_agent(grazie_llm, openai_llm):
    for llm in [grazie_llm, openai_llm]:
        agent = create_react_agent(llm, [blackbox])
        inputs = {"messages": [("user", "Some user request.")]}
        try:
            for chunk in agent.stream(inputs, {"recursion_limit": 4}, stream_mode="values"):
                ...
        except GraphRecursionError:
            print("Agent stopped due to max iterations.")

        assert len(chunk["messages"]) == 4
        assert isinstance(chunk["messages"][0], HumanMessage) and chunk["messages"][0].content == "Some user request."
        assert isinstance(chunk["messages"][1], AIMessage) and chunk["messages"][1].tool_calls[0]["args"] == {
            "a": "5",
            "b": "7",
        }
        assert isinstance(chunk["messages"][1], AIMessage) and chunk["messages"][1].tool_calls[0]["name"] == "blackbox"
        assert isinstance(chunk["messages"][1], AIMessage) and chunk["messages"][1].tool_calls[0]["type"] == "tool_call"
        assert isinstance(chunk["messages"][2], ToolMessage) and chunk["messages"][2].content == "12"
        assert (
            isinstance(chunk["messages"][3], AIMessage)
            and chunk["messages"][3].content == "Sorry, need more steps to process this request."
        )  # default langgraph answer when hitting a limit
