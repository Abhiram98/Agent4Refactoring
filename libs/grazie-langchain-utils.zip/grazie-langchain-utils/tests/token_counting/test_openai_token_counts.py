import pytest

from grazie_langchain_utils.utils.providers_utils import OpenAIUtils


@pytest.mark.parametrize("model_name,api_num_tokens", [("gpt-3.5-turbo", 23), ("gpt-4o", 23), ("gpt-4o-mini", 23)])
def test_single_message(model_name, api_num_tokens):
    messages = [
        {"role": "system", "content": "you are a friendly AI assistant <3"},
        {"role": "user", "content": "how are you?"},
    ]
    openai_utils = OpenAIUtils(model_name=model_name)

    computed_num_tokens = openai_utils.count_tokens_messages(messages)
    assert abs(api_num_tokens - computed_num_tokens) <= 1


@pytest.mark.parametrize("model_name,api_num_tokens", [("gpt-3.5-turbo", 35), ("gpt-4o", 34), ("gpt-4o-mini", 34)])
def test_simple_chat(model_name, api_num_tokens):
    messages = [
        {"role": "system", "content": "you are a friendly AI assistant <3"},
        {"role": "user", "content": "how are you?"},
        {"role": "assistant", "content": "alright"},
        {"role": "user", "content": "yay"},
    ]
    openai_utils = OpenAIUtils(model_name=model_name)

    computed_num_tokens = openai_utils.count_tokens_messages(messages)
    assert abs(api_num_tokens - computed_num_tokens) <= 1


@pytest.mark.parametrize("model_name,api_num_tokens", [("gpt-3.5-turbo", 117), ("gpt-4o", 113), ("gpt-4o-mini", 113)])
def test_message_with_tools(model_name, api_num_tokens):
    tools = [
        {
            "type": "function",
            "function": {
                "name": "get_delivery_date",
                "description": "Get the delivery date for a customer's order. Call this whenever you need to know the delivery date, for example when a customer asks 'Where is my package'",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "order_id": {
                            "type": "string",
                            "description": "The customer's order ID.",
                        },
                    },
                    "required": ["order_id"],
                    "additionalProperties": False,
                },
            },
        }
    ]
    messages = [
        {
            "role": "system",
            "content": "You are a helpful customer support assistant. Use the supplied tools to assist the user.",
        },
        {"role": "user", "content": "Hi, can you tell me the delivery date for my order? id is 123123123"},
    ]

    openai_utils = OpenAIUtils(model_name=model_name)

    computed_num_tokens = openai_utils.count_tokens_messages(messages, tools=tools)
    assert abs(api_num_tokens - computed_num_tokens) <= 5


@pytest.mark.parametrize("model_name,api_num_tokens", [("gpt-3.5-turbo", 173), ("gpt-4o", 169), ("gpt-4o-mini", 169)])
def test_tool_call(model_name, api_num_tokens):
    tools = [
        {
            "type": "function",
            "function": {
                "name": "get_delivery_date",
                "description": "Get the delivery date for a customer's order. Call this whenever you need to know the delivery date, for example when a customer asks 'Where is my package'",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "order_id": {
                            "type": "string",
                            "description": "The customer's order ID.",
                        },
                    },
                    "required": ["order_id"],
                    "additionalProperties": False,
                },
            },
        }
    ]
    messages = [
        {
            "role": "system",
            "content": "You are a helpful customer support assistant. Use the supplied tools to assist the user.",
        },
        {"role": "user", "content": "Hi, can you tell me the delivery date for my order? id is 123123123"},
        {
            "content": None,
            "role": "assistant",
            "tool_calls": [
                {
                    "id": "call_kTgqBrjJme4f9JWxB1vX7UhN",
                    "function": {"arguments": '{\n  "order_id": "123123123"\n}', "name": "get_delivery_date"},
                    "type": "function",
                }
            ],
            "refusal": None,
        },
        {
            "role": "tool",
            "content": '{"order_id": "order_123123123", "delivery_date": "2024-08-14 15:45:50"}',
            "tool_call_id": "call_kTgqBrjJme4f9JWxB1vX7UhN",
        },
    ]

    openai_utils = OpenAIUtils(model_name=model_name)

    computed_num_tokens = openai_utils.count_tokens_messages(messages, tools=tools)
    assert abs(api_num_tokens - computed_num_tokens) <= 5
