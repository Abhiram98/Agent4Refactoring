from decimal import Decimal
from typing import Iterator
from unittest.mock import MagicMock

import pytest
from grazie.api.client.chat.response import ChatResponse, ChatResponseStream, Credit
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import tool

from grazie_langchain_utils.callbacks import GrazieInfoCallbackHandler, get_token_counter_callback
from grazie_langchain_utils.language_models.grazie import ChatGrazie
from grazie_langchain_utils.language_models.input_output_utils import convert_messages_to_prompt
from grazie_langchain_utils.utils.token_counter import GrazieTokenCounter


@pytest.fixture
def grazie_fixture():
    grazie_llm = ChatGrazie(client=MagicMock(), profile="openai-chat-gpt")

    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "my system message",
            ),
            ("human", "my user message"),
        ]
    )
    return grazie_llm, prompt


@pytest.fixture
def grazie_streaming_fixture():
    grazie_llm = ChatGrazie(client=MagicMock(), profile="openai-chat-gpt", streaming=True)

    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "my system message",
            ),
            ("human", "my user message"),
        ]
    )
    return grazie_llm, prompt


@pytest.fixture
def grazie_token_counter():
    return GrazieTokenCounter(profile="openai-chat-gpt")


def test_single_message(grazie_fixture, grazie_token_counter):
    grazie_llm, prompt = grazie_fixture

    grazie_llm.client.chat.return_value = ChatResponse(
        prompt=convert_messages_to_prompt(prompt.invoke({}).to_messages()),
        content="my assistant answer",
        spent=Credit(amount=Decimal(2)),
    )

    grazie_chain = prompt | grazie_llm

    # explicit usage
    cb = GrazieInfoCallbackHandler(profile=grazie_llm.profile)
    response = grazie_chain.invoke({"input": "anything"}, config={"callbacks": [cb]})

    prompt_tokens = grazie_token_counter.count_tokens_langchain(prompt.invoke({}).to_messages())
    completion_tokens = grazie_token_counter.count_tokens_langchain([response])

    assert cb.prompt_tokens == prompt_tokens
    assert cb.completion_tokens == completion_tokens
    assert cb.total_tokens == prompt_tokens + completion_tokens
    assert cb.successful_requests == 1
    assert cb.total_cost == Decimal(2)

    # context manager usage
    with get_token_counter_callback(profile=grazie_llm.profile) as cb_context:
        response = grazie_chain.invoke({"input": "anything"})

        prompt_tokens = grazie_token_counter.count_tokens_langchain(prompt.invoke({}).to_messages())
        completion_tokens = grazie_token_counter.count_tokens_langchain([response])

        assert cb_context.prompt_tokens == prompt_tokens
        assert cb_context.completion_tokens == completion_tokens
        assert cb_context.total_tokens == prompt_tokens + completion_tokens
        assert cb_context.successful_requests == 1
        assert cb_context.total_cost == Decimal(2)


def test_simple_chat(grazie_fixture, grazie_token_counter):
    grazie_llm, prompt = grazie_fixture
    grazie_chain = prompt | grazie_llm

    grazie_llm.client.chat.return_value = ChatResponse(
        prompt=convert_messages_to_prompt(prompt.invoke({}).to_messages()),
        content="my assistant answer 1",
        spent=Credit(amount=Decimal(2)),
    )

    # explicit usage
    cb = GrazieInfoCallbackHandler(profile=grazie_llm.profile)
    response1 = grazie_chain.invoke({"input": "anything"}, config={"callbacks": [cb]})

    prompt_tokens1 = grazie_token_counter.count_tokens_langchain(prompt.invoke({}).to_messages())
    completion_tokens1 = grazie_token_counter.count_tokens_langchain([response1])

    assert cb.prompt_tokens == prompt_tokens1
    assert cb.completion_tokens == completion_tokens1
    assert cb.total_tokens == prompt_tokens1 + completion_tokens1
    assert cb.successful_requests == 1
    assert cb.total_cost == Decimal(2)

    grazie_llm.client.chat.return_value = ChatResponse(
        prompt=convert_messages_to_prompt(prompt.invoke({}).to_messages()),
        content="my assistant answer 2",
        spent=Credit(amount=Decimal(333)),
    )

    response2 = grazie_chain.invoke({"input": "anything"}, config={"callbacks": [cb]})

    prompt_tokens2 = grazie_token_counter.count_tokens_langchain(prompt.invoke({}).to_messages())
    completion_tokens2 = grazie_token_counter.count_tokens_langchain([response2])

    assert cb.prompt_tokens == prompt_tokens1 + prompt_tokens2
    assert cb.completion_tokens == completion_tokens1 + completion_tokens2
    assert cb.total_tokens == prompt_tokens1 + completion_tokens1 + prompt_tokens2 + completion_tokens2
    assert cb.successful_requests == 2
    assert cb.total_cost == Decimal(2) + Decimal(333)

    # context manager usage
    with get_token_counter_callback(profile=grazie_llm.profile) as cb_context:
        grazie_llm.client.chat.return_value = ChatResponse(
            prompt=convert_messages_to_prompt(prompt.invoke({}).to_messages()),
            content="my assistant answer 1",
            spent=Credit(amount=Decimal(2)),
        )

        response1 = grazie_chain.invoke({"input": "anything"})
        prompt_tokens1 = grazie_token_counter.count_tokens_langchain(prompt.invoke({}).to_messages())
        completion_tokens1 = grazie_token_counter.count_tokens_langchain([response1])

        assert cb_context.prompt_tokens == prompt_tokens1
        assert cb_context.completion_tokens == completion_tokens1
        assert cb_context.total_tokens == prompt_tokens1 + completion_tokens1
        assert cb_context.successful_requests == 1
        assert cb_context.total_cost == Decimal(2)

        grazie_llm.client.chat.return_value = ChatResponse(
            prompt=convert_messages_to_prompt(prompt.invoke({}).to_messages()),
            content="my assistant answer 2",
            spent=Credit(amount=Decimal(333)),
        )

        response2 = grazie_chain.invoke({"input": "anything else"})

        prompt_tokens2 = grazie_token_counter.count_tokens_langchain(prompt.invoke({}).to_messages())
        completion_tokens2 = grazie_token_counter.count_tokens_langchain([response2])

        assert cb_context.prompt_tokens == prompt_tokens1 + prompt_tokens2
        assert cb_context.completion_tokens == completion_tokens1 + completion_tokens2
        assert cb_context.total_tokens == prompt_tokens1 + completion_tokens1 + prompt_tokens2 + completion_tokens2
        assert cb_context.successful_requests == 2
        assert cb_context.total_cost == Decimal(2) + Decimal(333)


def test_tool_call(grazie_fixture, grazie_token_counter):
    @tool
    def search(query: str) -> str:
        """Searches the web for a given query."""
        return "Nothing found!"

    grazie_llm, prompt = grazie_fixture

    grazie_llm.client.chat.return_value = ChatResponse(
        prompt=convert_messages_to_prompt(prompt.invoke({}).to_messages()),
        content='{\n  "query": "something"\n}',
        function_call="search",
        spent=Credit(amount=Decimal(2)),
    )

    grazie_chain = prompt | grazie_llm.bind_tools([search])

    # explicit usage
    cb = GrazieInfoCallbackHandler(profile=grazie_llm.profile)
    response = grazie_chain.invoke({"input": "anything"}, config={"callbacks": [cb]})

    prompt_tokens = grazie_token_counter.count_tokens_langchain(prompt.invoke({}).to_messages(), tools=[search])
    completion_tokens = grazie_token_counter.count_tokens_langchain([response])

    assert cb.prompt_tokens == prompt_tokens
    assert cb.completion_tokens == completion_tokens
    assert cb.total_tokens == prompt_tokens + completion_tokens
    assert cb.successful_requests == 1
    assert cb.total_cost == Decimal(2)

    # context manager usage
    with get_token_counter_callback(profile=grazie_llm.profile) as cb_context:
        response = grazie_chain.invoke({"input": "anything"})

        prompt_tokens = grazie_token_counter.count_tokens_langchain(prompt.invoke({}).to_messages(), tools=[search])
        completion_tokens = grazie_token_counter.count_tokens_langchain([response])

        assert cb_context.prompt_tokens == prompt_tokens
        assert cb_context.completion_tokens == completion_tokens
        assert cb_context.total_tokens == prompt_tokens + completion_tokens
        assert cb_context.successful_requests == 1
        assert cb_context.total_cost == Decimal(2)


def test_single_message_streaming(grazie_fixture, grazie_streaming_fixture):
    grazie_llm, prompt = grazie_fixture
    grazie_llm_streaming, prompt = grazie_streaming_fixture

    grazie_llm.client.chat.return_value = ChatResponse(
        prompt=convert_messages_to_prompt(prompt.invoke({}).to_messages()),
        content="my assistant answer",
        spent=Credit(amount=Decimal(2)),
    )

    def mock_generator() -> Iterator[ChatResponseStream]:
        yield ChatResponseStream(chunk="my", function_call=None, updated=None, spent=None)
        yield ChatResponseStream(chunk=" assistant answer", function_call=None, updated=None, spent=Credit(Decimal(2)))

    grazie_llm_streaming.client.chat_stream.return_value = mock_generator()

    grazie_chain = prompt | grazie_llm

    cb = GrazieInfoCallbackHandler(profile=grazie_llm.profile)
    grazie_chain.invoke({"input": "anything"}, config={"callbacks": [cb]})

    grazie_chain_streaming = prompt | grazie_llm_streaming
    cb_streaming = GrazieInfoCallbackHandler(profile=grazie_llm_streaming.profile)
    grazie_chain_streaming.invoke({"input": "anything"}, config={"callbacks": [cb_streaming]})

    assert cb_streaming.total_cost == cb.total_cost
    assert cb_streaming.total_tokens == cb.total_tokens
    assert cb_streaming.prompt_tokens == cb.prompt_tokens
    assert cb_streaming.completion_tokens == cb.completion_tokens
    assert cb_streaming.successful_requests == cb.successful_requests


def test_tool_call_streaming(grazie_fixture, grazie_streaming_fixture):
    grazie_llm, prompt = grazie_fixture
    grazie_llm_streaming, prompt = grazie_fixture

    @tool
    def search(query: str) -> str:
        """Searches the web for a given query."""
        return "Nothing found!"

    grazie_llm.client.chat.return_value = ChatResponse(
        prompt=convert_messages_to_prompt(prompt.invoke({}).to_messages()),
        content='{\n  "query": "something"\n}',
        function_call="search",
        spent=Credit(amount=Decimal(2)),
    )
    grazie_chain = prompt | grazie_llm.bind_tools([search])

    def mock_generator() -> Iterator[ChatResponseStream]:
        yield ChatResponseStream(chunk="", function_call="search", updated=None, spent=None)
        yield ChatResponseStream(chunk='{\n  "query":', function_call=None, updated=None, spent=None)
        yield ChatResponseStream(chunk=' "something"\n}', function_call=None, updated=None, spent=Credit(Decimal(2)))

    grazie_llm_streaming.client.chat_stream.return_value = mock_generator()
    grazie_chain_streaming = prompt | grazie_llm_streaming.bind_tools([search])

    cb = GrazieInfoCallbackHandler(profile=grazie_llm.profile)
    grazie_chain.invoke({"input": "anything"}, config={"callbacks": [cb]})

    cb_streaming = GrazieInfoCallbackHandler(profile=grazie_llm_streaming.profile)
    grazie_chain_streaming.invoke({"input": "anything"}, config={"callbacks": [cb_streaming]})

    assert cb_streaming.total_cost == cb.total_cost
    assert cb_streaming.total_tokens == cb.total_tokens
    assert cb_streaming.prompt_tokens == cb.prompt_tokens
    assert cb_streaming.completion_tokens == cb.completion_tokens
    assert cb_streaming.successful_requests == cb.successful_requests
