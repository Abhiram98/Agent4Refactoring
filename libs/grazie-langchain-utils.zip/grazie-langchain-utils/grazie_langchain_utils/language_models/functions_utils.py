from typing import (
    Any,
    Callable,
    Dict,
    Type,
    Union,
)

from grazie.api.client.llm_functions import FunctionDefinition
from langchain_core.tools import BaseTool
from langchain_core.utils.function_calling import convert_to_openai_function
from langchain_core.utils.pydantic import is_basemodel_subclass
from pydantic import BaseModel


def convert_to_json_schema(
    function: Union[FunctionDefinition, Dict[str, Any], Type[BaseModel], Callable, BaseTool],
) -> Dict[str, Any]:
    if (
        isinstance(function, BaseTool)
        or callable(function)
        or isinstance(function, Dict)
        or (isinstance(function, type) and is_basemodel_subclass(function))
    ):
        return convert_to_openai_function(function)
    elif isinstance(function, FunctionDefinition):
        return _convert_function_definition_to_json_schema(function)
    else:
        raise ValueError(
            f"Unsupported function type {type(function)}\nFunctions must be passed in"
            " as grazie.api.client.llm_functions.FunctionDefinition, Dict,"
            " subclasses of pydantic.BaseModel, Callable, or langchain_core.tools.BaseTool."
        )


def _convert_function_definition_to_json_schema(function: FunctionDefinition) -> Dict[str, Any]:
    return {
        "name": function.name,
        "description": function.description,
        "parameters": function.parameters,
    }
