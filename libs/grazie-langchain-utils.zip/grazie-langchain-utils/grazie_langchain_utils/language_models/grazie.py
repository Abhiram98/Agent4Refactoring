from typing import (
    Any,
    Callable,
    Dict,
    Iterator,
    List,
    Optional,
    Sequence,
    Type,
    Union,
)

from grazie.api.client.endpoints import GrazieApiGatewayUrls
from grazie.api.client.gateway import (
    AuthType,
    GrazieAgent,
    GrazieApiGatewayClient,
)
from grazie.api.client.llm_functions import FunctionDefinition
from grazie.api.client.llm_parameters import LLMParameters
from grazie.api.client.parameters import Parameters
from grazie.api.client.profiles import Profile, LLMProfile
from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.language_models import BaseChatModel, LanguageModelInput
from langchain_core.language_models.chat_models import LangSmithParams, generate_from_stream
from langchain_core.messages import (
    AIMessageChunk,
    BaseMessage,
)
from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, ChatResult
from langchain_core.pydantic_v1 import BaseModel, Field, root_validator, SecretStr
# from pydantic import SecretStr
from langchain_core.runnables import Runnable
from langchain_core.tools import BaseTool

from .functions_utils import convert_to_json_schema
from .input_output_utils import convert_messages_to_prompt, convert_response_to_message


class ChatGrazie(BaseChatModel):
    class Config:  # type: ignore
        validate_all = True
        arbitrary_types_allowed = True
        use_enum_values = False

    client: Any = Field(default=None, exclude=True)

    agent: Any = Field(default=None, exclude=True)
    client_agent_name: str = Field(
        default="grazie-langchain",
        description="meaningful identifier of the application or user which is using the api",
    )
    client_agent_version: str = Field(default="dev")
    client_auth_type: str = Field(
        default="user"
    )  # TODO some bug with pydantic: if I set type to AuthType, then in validate_environment this field is missing. I'll leave it as str and make a workaround. Perhaps this is fixed in v2...

    client_url: str = Field(default=GrazieApiGatewayUrls.PRODUCTION)

    grazie_jwt_token: Optional[SecretStr] = Field(default=None)

    profile: str = Field(default=Profile.OPENAI_CHAT_GPT.name)
    """Profile (model) name to use."""

    max_tokens_to_sample: int = Field(default=256)
    """Denotes the number of tokens to predict per generation."""

    temperature: Optional[float] = None
    """A non-negative float that tunes the degree of randomness in generation."""

    streaming: bool = False
    """Whether to stream the results."""

    @property
    def lc_secrets(self) -> Dict[str, str]:
        return {"grazie_jwt_token": "GRAZIE_JWT_TOKEN"}

    @property
    def _llm_type(self) -> str:
        """Return type of chat model."""
        return "grazie-chat"

    @classmethod
    def is_lc_serializable(cls) -> bool:
        """Return whether this model can be serialized by Langchain."""
        return True

    @classmethod
    def get_lc_namespace(cls) -> List[str]:
        """Get the namespace of the langchain object."""
        return ["lang_ide_former", "chat_models", "grazie"]

    @root_validator()
    def validate_environment(cls, values: Dict) -> Dict:
        # TODO workaround: see client_auth_type field description
        if isinstance(values["client_auth_type"], str):
            values["client_auth_type"] = AuthType[values["client_auth_type"].upper()]

        if values.get("agent", None) is None:
            values["agent"] = GrazieAgent(values["client_agent_name"], values["client_agent_version"])

        if values.get("client", None) is None:
            values["client"] = GrazieApiGatewayClient(
                grazie_agent=values["agent"],
                grazie_jwt_token=values["grazie_jwt_token"].get_secret_value(),
                auth_type=values["client_auth_type"],
                url=values["client_url"],
            )

        return values

    def _get_invocation_params(
        self,
        stop: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        raw_params = super()._get_invocation_params()
        params = {
            **{key: value for key, value in raw_params.items() if key != "parameters"},
            "parameters": {param.fqdn: raw_params["parameters"][param].value for param in raw_params["parameters"]},
        }
        if "functions" in kwargs:
            params["functions"] = kwargs["functions"]
        params["streaming"] = self.streaming
        return params

    def _get_ls_params(self, stop: Optional[List[str]] = None, **kwargs: Any) -> LangSmithParams:
        """Get standard params for tracing."""
        params = self._get_invocation_params(stop=stop, **kwargs)
        ls_params = LangSmithParams(
            ls_provider="grazie",
            ls_model_name=self.profile,
            ls_model_type="chat",
            ls_temperature=params.get(LLMParameters.Temperature.fqdn, self.temperature),
        )
        if ls_max_tokens := params.get("max_tokens_to_sample", self.max_tokens_to_sample):
            ls_params["ls_max_tokens"] = ls_max_tokens
        if ls_stop := stop or params.get("stop", None):
            ls_params["ls_stop"] = ls_stop
        return ls_params

    @property
    def _default_params(self) -> Dict[str, Any]:
        """Get the default parameters."""
        d: Dict[str, Any] = {
            "profile": LLMProfile(self.profile),
        }
        parameters: Dict[Any, Any] = {LLMParameters.Length: Parameters.IntValue(self.max_tokens_to_sample)}
        if self.temperature is not None:
            parameters[LLMParameters.Temperature] = Parameters.FloatValue(self.temperature)

        d["parameters"] = parameters
        return d

    @property
    def _identifying_params(self) -> Dict[str, Any]:
        """Get the identifying parameters."""
        return self._default_params

    def _construct_chat_params(self, kwargs):
        params = self._default_params

        parameters = params.get("parameters", {})
        if "parameters" in kwargs:
            # override only the parameters that are present in kwargs, not all of them
            parameters = {**parameters, **kwargs["parameters"]}  # type: ignore
        if "functions" in kwargs:
            parameters[LLMParameters.Functions] = Parameters.JsonValue(
                value=[convert_to_json_schema(func) for func in kwargs["functions"]]
            )
        if "function_call" in kwargs:
            parameters[LLMParameters.FunctionCall] = Parameters.JsonValue(kwargs["function_call"])
        params = {
            **{key: value for key, value in params.items() if key != "parameters"},
            **{key: value for key, value in kwargs.items() if key not in {"functions", "function_call", "parameters"}},
            "parameters": parameters,
        }
        return params

    def _prepare_inputs(self, messages: List[BaseMessage], **kwargs):
        prompt = convert_messages_to_prompt(messages)
        params = self._construct_chat_params(kwargs)
        return prompt, params

    # stop isn't actually supported by python grazie client
    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        # top level for generation: delegates to _stream if implemented, and stream is doing same, but in stream/chunked manner
        if self.streaming:
            stream_iter = self._stream(messages, stop=stop, run_manager=run_manager, **kwargs)
            return generate_from_stream(stream_iter)

        prompt, params = self._prepare_inputs(messages=messages, **kwargs)
        response = self.client.chat(chat=prompt, **params)
        message = convert_response_to_message(response)

        if response.spent:
            message.additional_kwargs["spent"] = response.spent
        return ChatResult(generations=[ChatGeneration(message=message)])

    # async stream is not supported, as grazie python client doesn't support it either
    def _stream(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> Iterator[ChatGenerationChunk]:
        prompt, params = self._prepare_inputs(messages=messages, **kwargs)

        stream = self.client.chat_stream(
            chat=prompt,
            **params,
        )
        for data in stream:
            delta = data.chunk
            additional_kwargs = {"function_call": data.function_call} if data.function_call is not None else {}
            lc_chunk = ChatGenerationChunk(
                message=AIMessageChunk(content=delta, additional_kwargs=additional_kwargs),
                generation_info={"spent": data.spent.amount} if data.spent else None,
            )
            yield lc_chunk

            if run_manager:
                run_manager.on_llm_new_token(delta, chunk=lc_chunk)

    def bind_tools(
        self,
        tools: Sequence[Union[FunctionDefinition, Dict[str, Any], Type[BaseModel], Callable, BaseTool]],
        **kwargs: Any,
    ) -> Runnable[LanguageModelInput, BaseMessage]:
        return super().bind(functions=tools, **kwargs)
