import json
import uuid
from typing import (
    List,
)

from grazie.api.client.chat.prompt import ChatPrompt
from grazie.api.client.chat.response import ChatResponse
from langchain_core.exceptions import OutputParserException
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    FunctionMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.messages.tool import ToolCall, invalid_tool_call, tool_call


def parse_tool_call(name: str, content: str, call_id: str) -> ToolCall:
    try:
        if len(content.strip()) == 0:
            # OpenAI returns an empty string for functions containing no args
            args = {}
        else:
            args = json.loads(content)
    except json.JSONDecodeError as e:
        raise OutputParserException(f"Error parsing tool call arguments: {content}") from e
    return tool_call(name=name, args=args, id=call_id)


def convert_response_to_message(response: ChatResponse) -> AIMessage:
    # Adapted from langchain_openai.chat_models.base._convert_dict_to_message
    content = response.content
    additional_kwargs = {}
    tool_calls = []
    invalid_tool_calls = []
    if raw_tool_call := response.function_call:
        # Grazie supports only one tool call per message
        call_id = f"call_{raw_tool_call}_{uuid.uuid4()}-temp"
        additional_kwargs["function_call"] = raw_tool_call
        try:
            tool_calls.append(parse_tool_call(name=raw_tool_call, content=content, call_id=call_id))
        except Exception as e:
            invalid_tool_calls.append(invalid_tool_call(name=raw_tool_call, args=content, id=call_id, error=str(e)))
    return AIMessage(
        content=content,
        additional_kwargs=additional_kwargs,
        tool_calls=tool_calls,
        invalid_tool_calls=invalid_tool_calls,
    )


def convert_messages_to_prompt(messages: List[BaseMessage]):
    prompt = ChatPrompt()

    for message in messages:
        if not isinstance(message.content, str):
            raise ValueError(
                "Grazie does not yet support non-string message content (i.e. list of strings within one message, dicts, etc)"
            )

        if isinstance(message, HumanMessage):
            prompt.add_user(message.content)
        elif isinstance(message, AIMessage):
            if "function_call" in message.additional_kwargs:
                name = message.additional_kwargs["function_call"]
                prompt.add_assistant_function(name=name, content=message.content)
            else:
                prompt.add_assistant(message.content)
        elif isinstance(message, SystemMessage):
            prompt.add_system(message.content)
        elif isinstance(message, FunctionMessage) or isinstance(message, ToolMessage):
            prompt.add_function(message.name, message.content)  # type: ignore[arg-type]
        else:
            raise ValueError(f"Unsupported message type {type(message)} for {message}")

    return prompt
