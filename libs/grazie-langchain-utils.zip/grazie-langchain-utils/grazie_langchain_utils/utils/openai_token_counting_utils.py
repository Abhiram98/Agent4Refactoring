# reused code from AutoGPT:
# https://github.com/Significant-Gravitas/AutoGPT/blob/3425b061b5e55b6b655d59d320c8c36895156830/autogpt/llm/providers/openai.py#L359
# a related discussion: https://community.openai.com/t/how-to-calculate-the-tokens-when-using-function-call/266573


from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class ParameterSpec:
    name: str
    type: str  # TODO: add enum support
    description: Optional[str]
    required: bool = False


@dataclass
class OpenAIFunctionSpec:
    """Represents a "function" in OpenAI, which is mapped to a Command in Auto-GPT"""

    name: str
    description: str
    parameters: Dict[str, ParameterSpec]

    @property
    def schema(self):
        """Returns an OpenAI-consumable function specification"""
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {
                "type": "object",
                "properties": {
                    param.name: {
                        "type": param.type,
                        "description": param.description,
                    }
                    for param in self.parameters.values()
                },
                "required": [param.name for param in self.parameters.values() if param.required],
            },
        }


def _format_function_specs_as_typescript_ns(functions: List[OpenAIFunctionSpec]) -> str:
    """Returns a function signature block in the format used by OpenAI internally:
    https://community.openai.com/t/how-to-calculate-the-tokens-when-using-function-call/266573/6

    Accurate to within 5 tokens when used with count_string_tokens :)

    Example given by OpenAI engineer:
    ```ts
    namespace functions {
      type x = (_: {
        location: string,
        unit?: "celsius" | "fahrenheit",
      }) => any;
    } // namespace functions
    ```

    Format found by further experimentation: (seems accurate to within 5 tokens)
    ```ts
    namespace functions {

    // Get the current weather in a given location
    type get_current_weather = (_: {
      location: string, // The city and state, e.g. San Francisco, CA
      unit?: "celsius" | "fahrenheit",
    }) => any;

    } // namespace functions
    ```
    The `namespace` statement doesn't seem to count towards total token length.
    """

    def param_signature(p_spec: ParameterSpec) -> str:
        # TODO: enum type support
        return f'{p_spec.name}{"" if p_spec.required else ""}: {p_spec.type}, // {p_spec.description}'

    def function_signature(f_spec: OpenAIFunctionSpec) -> str:
        return "\n".join(
            [
                f"// {f_spec.description}",
                f"type {f_spec.name} = (_ :{{",
                *[f"  {param_signature(p)}" for p in f_spec.parameters.values()],
                "}) => any;",
            ]
        )

    return (
        "namespace functions {\n\n"
        + "\n\n".join(function_signature(f) for f in functions)
        + "\n\n} // namespace functions"
    )


def format_function_specs_as_typescript_ns(functions: List[Dict[str, Any]]) -> str:
    """Same as _format_function_specs_as_typescript_ns, but accepts functions in usual OpenAI format
    instead of custom classes.

    ```
    {
        "type": "function",
        "function": {
            "name": "bing_bong",
            "description": "Do a bing bong",
            "parameters": {
                "type": "object",
                "properties": {
                    "foo": {
                        "type": "string"
                    },
                    "bar": {
                        "type": "number",
                        "description": "A number"
                    }
                }
            }
        }
    }
    ```
    """

    converted_functions = []
    for function in functions:
        converted_functions.append(
            OpenAIFunctionSpec(
                name=function["function"]["name"],
                description=function["function"]["description"],
                parameters={
                    param: ParameterSpec(
                        name=param,
                        type=function["function"]["parameters"]["properties"][param]["type"],
                        description=function["function"]["parameters"]["properties"][param].get("description"),
                        required=param in function["function"]["parameters"]["required"],
                    )
                    for param in function["function"]["parameters"]["properties"]
                },
            )
        )

    return _format_function_specs_as_typescript_ns(converted_functions)
