import logging
import uuid
from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Dict, List, Optional, Sequence

import tiktoken
from grazie.api.client.chat.message import AssistantChatMessage, FunctionCallChatMessage, TextChatMessage
from grazie.api.client.chat.prompt import ChatPrompt
from grazie.api.client.profiles import LLMProfile
from langchain_core.messages import BaseMessage
from langchain_core.tools import BaseTool
from langchain_core.utils.function_calling import convert_to_openai_tool
from langchain_openai.chat_models.base import _convert_message_to_dict as convert_message_openai

from .openai_token_counting_utils import format_function_specs_as_typescript_ns


class ModelProvider(Enum):
    GRAZIE = "grazie"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"
    OPENAI = "openai"

    @classmethod
    def from_profile(cls, profile: LLMProfile) -> "ModelProvider":
        return cls(profile.organization())

    def get_utils(self, model_name: str):
        if self == ModelProvider.GRAZIE:
            raise NotImplementedError("Currently, grazie models are not supported.")
        elif self == ModelProvider.ANTHROPIC:
            raise NotImplementedError("Currently, Anthropic models are not supported.")
        elif self == ModelProvider.GOOGLE:
            raise NotImplementedError("Currently, Google models are not supported.")
        elif self == ModelProvider.OPENAI:
            return OpenAIUtils(model_name)


class BaseProviderUtils(ABC):
    def __init__(self, model_name: str):
        self.model_name = model_name

    @staticmethod
    @abstractmethod
    def convert_messages_grazie(prompt: ChatPrompt) -> Any: ...

    @staticmethod
    @abstractmethod
    def convert_messages_langchain(messages: List[BaseMessage]) -> Any: ...

    @abstractmethod
    def convert_tools_langchain(self, tools: Sequence[BaseTool]) -> Any: ...

    @abstractmethod
    def count_tokens_text(self, text: str) -> int: ...

    @abstractmethod
    def count_tokens_messages(self, messages: Any, tools: Optional[Any] = None) -> int: ...


class OpenAIUtils(BaseProviderUtils):
    OPENAI_MODELS_TO_VERSIONS = {
        "gpt-3.5-turbo": "gpt-3.5-turbo-0125",
        "gpt-4": "gpt-4-0613",
        "gpt-4-turbo": "gpt-4-turbo-2024-04-09",
        "gpt-4o": "gpt-4o-2024-05-13",
        "gpt-4o-mini": "gpt-4o-mini-2024-07-18",
    }

    def __init__(self, model_name: str):
        if model_name in self.OPENAI_MODELS_TO_VERSIONS:
            logging.debug(f"Assuming {model_name} to point to {self.OPENAI_MODELS_TO_VERSIONS[model_name]}.")
            model_name = self.OPENAI_MODELS_TO_VERSIONS[model_name]
        super().__init__(model_name)
        self._tokenizer = tiktoken.encoding_for_model(self.model_name)

    @staticmethod
    def convert_messages_grazie(prompt: ChatPrompt) -> List[Dict[str, Any]]:
        # based on spec here: https://platform.openai.com/docs/api-reference/chat/create#chat-create-messages
        messages: List[Dict[str, Any]] = []
        for message in prompt.messages:
            if isinstance(message, TextChatMessage):
                messages.append({"role": message.role.value.lower(), "content": message.text})
            elif isinstance(message, AssistantChatMessage):
                messages.append(
                    {
                        "role": "assistant",
                        "content": message.text,
                        "tool_calls": [
                            {
                                "id": f"call_{message.functionCall.functionName}_{uuid.uuid4()}-temp",
                                "type": "function",
                                "function": {
                                    "name": message.functionCall.functionName,
                                    "arguments": message.functionCall.content,
                                },
                            }
                        ]
                        if message.functionCall
                        else None,
                    }
                )
            elif isinstance(message, FunctionCallChatMessage):
                messages.append({"role": "function", "name": message.name, "content": message.content})
        return messages

    @staticmethod
    def convert_messages_langchain(messages: List[BaseMessage]) -> List[Dict[str, Any]]:
        return [convert_message_openai(message) for message in messages]

    def convert_tools_langchain(self, tools: Sequence[BaseTool]) -> Any:
        return [convert_to_openai_tool(t) for t in tools]

    def count_tokens_text(self, text: str) -> int:
        return len(self._tokenizer.encode(text))

    def count_tokens_messages(
        self, messages: List[Dict[str, Any]], tools: Optional[List[Dict[str, Any]]] = None
    ) -> int:
        """Return the number of tokens used by a list of messages.

        Adapted from https://github.com/openai/openai-cookbook/blob/main/examples/How_to_count_tokens_with_tiktoken.ipynb.

        Note: serves as an approximation, since there are no fully detailed explanations/examples on tokenization for
            newer models and function calling.
        """
        if self.model_name in {
            "gpt-3.5-turbo-0613",
            "gpt-3.5-turbo-16k-0613",
            "gpt-4-0314",
            "gpt-4-32k-0314",
            "gpt-4-0613",
            "gpt-4-32k-0613",
            # there model aren't there in the example, but I don't see better options :(
            "gpt-3.5-turbo-0125",
            "gpt-4-turbo-2024-04-09",
            "gpt-4o-2024-05-13",
            "gpt-4o-mini-2024-07-18",
        }:
            tokens_per_message = 3
            tokens_per_name = 1
        elif self.model_name == "gpt-3.5-turbo-0301":
            tokens_per_message = 4  # every message follows <|start|>{role/name}\n{content}<|end|>\n
            tokens_per_name = -1  # if there's a name, the role is omitted
        else:
            raise NotImplementedError(
                f"""OpenAIUtils.count_tokens_messages is not implemented for model {self.model_name}."""
            )
        num_tokens = 0
        for message in messages:
            num_tokens += tokens_per_message
            for key, value in message.items():
                if key == "name":
                    num_tokens += tokens_per_name
                # This is an inferred approximation. OpenAI does not document how to
                # count tool message tokens.
                if key == "tool_call_id":
                    num_tokens += 3
                    continue
                if isinstance(value, list):
                    for val in value:
                        if isinstance(val, str) or val["type"] == "text":
                            text = val["text"] if isinstance(val, dict) else val
                            num_tokens += self.count_tokens_text(text)
                        # Tool/function call token counting is not documented by OpenAI.
                        # This is an approximation.
                        elif val["type"] == "function":
                            num_tokens += self.count_tokens_text(val["function"]["arguments"])
                            num_tokens += self.count_tokens_text(val["function"]["name"])
                        else:
                            raise ValueError(f"Unrecognized content block type\n\n{val}")
                elif not value:
                    continue
                else:
                    # Cast str(value) in case the message value is not a string
                    # This occurs with function messages
                    num_tokens += self.count_tokens_text(str(value))
        num_tokens += 3  # every reply is primed with <|start|>assistant<|message|>

        # estimate tokens for tools' definition
        if tools:
            num_tokens += self.count_tokens_text(format_function_specs_as_typescript_ns(tools))

        return num_tokens
