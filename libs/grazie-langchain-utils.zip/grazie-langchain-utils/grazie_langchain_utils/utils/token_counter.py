from typing import List, Optional, Sequence

from grazie.api.client.chat.prompt import ChatPrompt
from grazie.api.client.completion.prompt import CompletionPrompt
from grazie.api.client.profiles import LLMProfile, Profile
from langchain_core.messages import BaseMessage
from langchain_core.tools import BaseTool

from grazie_langchain_utils.utils.providers_utils import ModelProvider


class GrazieTokenCounter:
    PROFILE_TO_MODEL_NAME = {
        # Local models
        Profile.GRAZIE_GPT_NEO_TINY_TEXT: "EleutherAI/gpt-neo-125m",
        Profile.GRAZIE_REPLIT_CODE_V1_SMALL: "replit/replit-code-v1-3b",
        Profile.GRAZIE_BIGCODE_STARCODER: "bigcode/starcoder",
        Profile.GRAZIE_CHAT_LLAMA_V2_7b: "meta-llama/Llama-2-7b-chat-hf",
        Profile.GRAZIE_CHAT_LLAMA_V2_13b: "meta-llama/Llama-2-13b-chat-hf",
        Profile.GRAZIE_CODE_LLAMA_7b: "meta-llama/CodeLlama-7b-hf",
        Profile.GRAZIE_CODE_LLAMA_13b: "meta-llama/CodeLlama-13b-hf",
        # Anthropic models
        Profile.ANTHROPIC_CLAUDE: None,
        Profile.ANTHROPIC_CLAUDE_INSTANT: None,
        Profile.ANTHROPIC_CLAUDE_3_HAIKU: "claude-3-haiku-20240307",
        Profile.ANTHROPIC_CLAUDE_3_SONNET: "claude-3-sonnet-20240229",
        Profile.ANTHROPIC_CLAUDE_3_OPUS: "claude-3-opus-20240229",
        Profile.ANTHROPIC_CLAUDE_35_SONNET: "claude-3-5-sonnet-20240620",
        # Google models
        Profile.GOOGLE_CHAT_BISON: "chat-bison",
        Profile.GOOGLE_CHAT_CODE_BISON: "codechat-bison",
        Profile.GOOGLE_COMPLETION_CODE_GECKO: "code-gecko",
        Profile.GOOGLE_COMPLETION_CODE_BISON: "code-bison",
        Profile.GOOGLE_CHAT_GEMINI_PRO: "gemini-1.0-pro",
        Profile.GOOGLE_CHAT_GEMINI_ULTRA: "gemini-1.0-ultra",
        Profile.GOOGLE_CHAT_GEMINI_PRO_15: "gemini-1.5-pro",
        # OpenAI models
        # embeddings
        Profile.OPENAI_EMBEDDING_ADA: "text-embedding-ada-002",
        Profile.OPENAI_EMBEDDING_SMALL: "text-embedding-3-small",
        Profile.OPENAI_EMBEDDING_LARGE: "text-embedding-3-large",
        # chat
        Profile.OPENAI_CHAT_GPT: "gpt-3.5-turbo",
        Profile.OPENAI_CHAT_GPT_16k: "gpt-3.5-turbo",
        Profile.OPENAI_GPT_4: "gpt-4",
        Profile.OPENAI_GPT_4_TURBO: "gpt-4-turbo",
        Profile.OPENAI_GPT_4_O: "gpt-4o",
        Profile.OPENAI_GPT_4_O_MINI: "gpt-4o-mini",
    }

    def __init__(self, profile: LLMProfile | str):
        if not isinstance(profile, LLMProfile):
            profile = Profile.get_by_name(profile)
        self._model_name = self.PROFILE_TO_MODEL_NAME.get(profile, None)
        if not self._model_name:
            raise ValueError(f"Model name is not defined for {profile.name}.")
        self.provider = ModelProvider.from_profile(profile)
        self.provider_utils = self.provider.get_utils(self._model_name)

    def count_tokens_grazie(
        self, prompt: ChatPrompt | CompletionPrompt, tools: Optional[Sequence[BaseTool]] = None
    ) -> int:
        """Estimates the number of tokens for a given Grazie prompt."""
        if isinstance(prompt, CompletionPrompt):
            return self.provider_utils.count_tokens(prompt.message)

        if isinstance(prompt, ChatPrompt):
            messages = self.provider_utils.convert_messages_grazie(prompt)
            return self.provider_utils.count_tokens_messages(
                messages, tools=tools if tools is None else self.provider_utils.convert_tools_langchain(tools)
            )

        raise ValueError(f"Unsupported prompt type: {type(prompt)}.")

    def count_tokens_langchain(self, messages: List[BaseMessage], tools: Optional[Sequence[BaseTool]] = None) -> int:
        """Estimates the number of tokens for a given list of LangChain messages."""
        messages = self.provider_utils.convert_messages_langchain(messages)
        return self.provider_utils.count_tokens_messages(
            messages, tools=tools if tools is None else self.provider_utils.convert_tools_langchain(tools)
        )
