import asyncio
import threading
import time
from collections import deque

from langchain_core.rate_limiters import BaseRateLimiter


class InMemorySlidingWindowRateLimiter(BaseRateLimiter):
    """A rate limiter based on a sliding window algorithm.

    This implementation enforces a precise limit on the number of requests
    within a configurable time window. It's thread-safe and compatible with
    both sync and async contexts.

    Args:
        max_requests: Maximum number of requests allowed within the sliding window.
        check_every_n_seconds: Check whether the request is allowed
                every this many seconds. Can be a float to represent
                fractions of a second.
        window_seconds: Duration of the sliding window in seconds.
    """

    def __init__(
        self, *, max_requests: int = 5000, check_every_n_seconds: float = 0.1, window_seconds: int = 3600
    ) -> None:
        self.max_requests = max_requests
        self.check_every_n_seconds = check_every_n_seconds
        self.window_seconds = window_seconds
        self.request_timestamps = deque()  # Store timestamps of requests
        self._lock = threading.Lock()  # Thread-safe access control

    def _cleanup(self) -> None:
        """Remove timestamps outside the sliding window."""
        current_time = time.monotonic()
        while self.request_timestamps and self.request_timestamps[0] < current_time - self.window_seconds:
            self.request_timestamps.popleft()

    def _can_acquire(self) -> bool:
        """Check if a new request can be allowed."""
        self._cleanup()
        return len(self.request_timestamps) < self.max_requests

    def acquire(self, *, blocking: bool = True) -> bool:
        """Attempt to acquire a token for a request (synchronous).

        Args:
            blocking: If True, blocks until a token is available. Defaults to True.

        Returns:
            True if the request is allowed, False otherwise.
        """
        while True:
            with self._lock:
                if self._can_acquire():
                    self.request_timestamps.append(time.monotonic())
                    return True
            if not blocking:
                return False
            time.sleep(self.check_every_n_seconds)

    async def aacquire(self, *, blocking: bool = True) -> bool:
        """Attempt to acquire a token for a request (asynchronous).

        Args:
            blocking: If True, blocks until a token is available. Defaults to True.

        Returns:
            True if the request is allowed, False otherwise.
        """
        while True:
            with self._lock:
                if self._can_acquire():
                    self.request_timestamps.append(time.monotonic())
                    return True
            if not blocking:
                return False
            await asyncio.sleep(self.check_every_n_seconds)
