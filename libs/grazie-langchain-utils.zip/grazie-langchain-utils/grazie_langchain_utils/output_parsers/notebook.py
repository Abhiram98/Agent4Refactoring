import json
import logging
from json import JSONDecodeError
from typing import Optional, Union

from langchain_core.agents import AgentAction, AgentActionMessageLog, AgentFinish
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
)

from .grazie_functions import GrazieFunctionsAgentOutputParser


class NotebookOutputParser(GrazieFunctionsAgentOutputParser):
    @staticmethod
    def extract_outer_braces(data: str) -> Optional[str]:
        count = 0
        start = -1
        for i in range(len(data)):
            if data[i] == "{":
                count += 1
                if start == -1:
                    start = i
            elif data[i] == "}":
                count -= 1
            if count == 0 and start != -1:
                return data[start : i + 1]
        return None

    @staticmethod
    def _parse_ai_message(message: BaseMessage) -> Union[AgentAction, AgentFinish]:
        """Parse an AI message."""
        if not isinstance(message, AIMessage):
            raise TypeError(f"Expected an AI message got {type(message)}")

        if not isinstance(message.content, str):
            raise ValueError(
                "Grazie does not yet support non-string message content (i.e. list of strings within one message, dicts, etc)"
            )
        function_call = message.additional_kwargs.get("function_call", None)

        if function_call:
            function_name = function_call
            try:
                if len(message.content.strip()) == 0:
                    # OpenAI returns an empty string for functions containing no args
                    _tool_input = {}
                else:
                    # otherwise it returns a json object
                    content_cleaned = NotebookOutputParser.extract_outer_braces(message.content)
                    _tool_input = json.loads(content_cleaned)  # type: ignore[arg-type, reportArgumentType]
            except JSONDecodeError:
                _tool_input = message.content  # type: ignore[assignment]
                logging.warning(
                    f"Could not parse tool input: {function_call} because "
                    f"the `arguments` is not valid JSON. Content is: {message.content}"
                    f"the additional kwargs the following: {message.additional_kwargs}"
                )

            tool_input = _tool_input

            content_msg = f"responded: {message.content}\n" if message.content else "\n"
            log = f"\nInvoking: `{function_name}` with `{tool_input}`\n{content_msg}\n"
            return AgentActionMessageLog(
                tool=function_name,
                tool_input=tool_input,
                log=log,
                message_log=[message],
            )

        return AgentFinish(return_values={"output": message.content}, log=str(message.content))
