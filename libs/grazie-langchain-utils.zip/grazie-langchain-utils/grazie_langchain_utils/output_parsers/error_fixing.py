import json
from json import JSONDecodeError
from typing import Optional, Union

from langchain_core.agents import AgentAction, AgentActionMessageLog, AgentFinish
from langchain_core.exceptions import OutputParserException
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
)

from .grazie_functions import GrazieFunctionsAgentOutputParser


class ErrorFixingAgentOutputParser(GrazieFunctionsAgentOutputParser):
    @property
    def _type(self) -> str:
        return "error-fixing-agent"

    @staticmethod
    def _parse_tool_input(text: str) -> Optional[str]:
        open_braces = 0
        json_start = 0
        json_end = 0
        for i in reversed(range(len(text))):
            if text[i] == "}":
                if open_braces == 0:
                    json_end = i + 1
                open_braces += 1
            elif text[i] == "{":
                open_braces -= 1
                if open_braces == 0:
                    json_start = i
                    break
        return text[json_start:json_end]

    @staticmethod
    def _parse_ai_message(message: BaseMessage) -> Union[AgentAction, AgentFinish]:
        """Parse an AI message.

        Format of message.content when message.function_call is provided:
        'Any text.{"tool_kwarg1": "value1", ...}'

        Will parse it into AgentAction(tool=messsage.function_call,
                                       tool_input={"tool_kwarg1": "value1", ...},
                                       log='Any text.')
        """
        if not isinstance(message, AIMessage):
            raise TypeError(f"Expected an AI message got {type(message)}")

        if not isinstance(message.content, str):
            raise ValueError(
                "Grazie does not yet support non-string message content (i.e. list of strings within one message, dicts, etc)"
            )

        function_call = message.additional_kwargs.get("function_call", None)

        if function_call:
            function_name = function_call
            try:
                if len(message.content.strip()) == 0:
                    _tool_input = {}
                else:
                    _tool_input = json.loads(ErrorFixingAgentOutputParser._parse_tool_input(message.content))  # type: ignore[arg-type]
            except JSONDecodeError:
                raise OutputParserException(
                    f"Could not parse tool input from {message.content}, because " f"it doesn't contain a valid JSON."
                )

            tool_input = _tool_input

            content_msg = f"responded: {message.content}\n" if message.content else "\n"
            log = f"\nInvoking: `{function_name}` with `{tool_input}`\n{content_msg}\n"
            return AgentActionMessageLog(
                tool=function_name,
                tool_input=tool_input,
                log=log,
                message_log=[message],
            )

        return AgentFinish(return_values={"output": message.content}, log=str(message.content))
