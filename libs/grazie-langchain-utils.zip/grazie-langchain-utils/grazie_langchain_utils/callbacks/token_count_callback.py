import threading
from decimal import Decimal
from typing import Any, Dict, List, Optional
from uuid import UUID

from grazie.api.client.chat.response import Credit
from grazie.api.client.profiles import LLMProfile
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import BaseMessage
from langchain_core.outputs import ChatGeneration, LLMResult

from grazie_langchain_utils.utils.token_counter import GrazieTokenCounter


class GrazieInfoCallbackHandler(BaseCallbackHandler):
    """Callback Handler that tracks info about tokens and costs for Grazie API

    Based on langchain_community.callbacks.OpenAICallbackHandler."""

    total_tokens: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    successful_requests: int = 0
    total_cost: Decimal = Decimal(0)

    def __init__(self, profile: LLMProfile | str) -> None:
        super().__init__()
        self._lock = threading.Lock()
        self._token_counter = GrazieTokenCounter(profile)

    def __repr__(self) -> str:
        return (
            f"Tokens Used: {self.total_tokens}\n"
            f"\tPrompt Tokens: {self.prompt_tokens}\n"
            f"\tCompletion Tokens: {self.completion_tokens}\n"
            f"Successful Requests: {self.successful_requests}\n"
            f"Total Cost (credits): {self.total_cost}"
        )

    @property
    def always_verbose(self) -> bool:
        """Whether to call verbose callbacks even if verbose is False."""
        return True

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[BaseMessage]],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        prompt_tokens = self._token_counter.count_tokens_langchain(
            messages[0], tools=kwargs.get("invocation_params", {}).get("functions")
        )
        with self._lock:
            self.prompt_tokens += prompt_tokens
            self.total_tokens += prompt_tokens

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        """Collect token usage."""
        completion_tokens, spent_credits = 0, Decimal(0)

        try:
            generation = response.generations[0][0]
        except IndexError:
            generation = None
        if isinstance(generation, ChatGeneration):
            try:
                message = generation.message
                completion_tokens = self._token_counter.count_tokens_langchain([message])
                spent_credits = message.additional_kwargs.get("spent", Credit(amount=Decimal(0))).amount

                if not spent_credits and generation.generation_info:
                    spent_credits = generation.generation_info.get("spent", Decimal(0))

                if isinstance(spent_credits, str):
                    spent_credits = Decimal(spent_credits)

            except Exception:
                ...

        with self._lock:
            self.total_cost += spent_credits
            self.total_tokens += completion_tokens
            self.completion_tokens += completion_tokens
            self.successful_requests += 1

        return None

    def __copy__(self) -> "GrazieInfoCallbackHandler":
        """Return a copy of the callback handler."""
        return self

    def __deepcopy__(self, memo: Any) -> "GrazieInfoCallbackHandler":
        """Return a deep copy of the callback handler."""
        return self
