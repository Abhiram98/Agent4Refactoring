from contextlib import contextmanager
from contextvars import ContextVar
from typing import Generator, Optional

from grazie.api.client.profiles import LLMProfile
from langchain_core.tracers.context import register_configure_hook

from .token_count_callback import GrazieInfoCallbackHandler

grazie_callback_var: ContextVar[Optional[GrazieInfoCallbackHandler]] = ContextVar("grazie_callback", default=None)
register_configure_hook(grazie_callback_var, True)


@contextmanager
def get_token_counter_callback(profile: LLMProfile | str) -> Generator[GrazieInfoCallbackHandler, None, None]:
    cb = GrazieInfoCallbackHandler(profile)
    grazie_callback_var.set(cb)
    yield cb
    grazie_callback_var.set(None)
